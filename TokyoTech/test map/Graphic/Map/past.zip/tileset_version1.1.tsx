<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tileset_version1.1" tilewidth="32" tileheight="32" tilecount="176" columns="16">
 <image source="simple_tileset_32x32_version1.1/tileset_version1.1.png" width="512" height="352"/>
</tileset>
